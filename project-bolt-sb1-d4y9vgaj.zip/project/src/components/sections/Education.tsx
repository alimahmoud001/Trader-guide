import React from 'react';
import { ExternalLink, Play, BookOpen, User } from 'lucide-react';

const courses = [
  {
    title: 'كورس كامل لتعلم التداول مع باتك',
    instructor: 'أشهر ملياردير عبقري التداول',
    platform: 'يوتيوب',
    url: 'https://youtube.com/@tradewithpatarabic?si=4egOIQw15KHmRJGy',
    icon: <Play className="w-6 h-6" />,
    color: 'red'
  },
  {
    title: 'قناة Smart Risk',
    instructor: 'محتوى تعليمي متقدم',
    platform: 'يوتيوب',
    url: 'https://youtube.com/@smart_risk?si=s0leP3OYv9GuCp3r',
    icon: <Play className="w-6 h-6" />,
    color: 'red'
  },
  {
    title: 'كورس التداول الشامل',
    instructor: 'كميل M5',
    platform: 'إنستغرام',
    url: 'https://www.instagram.com/kameel_m5?igsh=YzljYTk1ODg3Zg==',
    icon: <BookOpen className="w-6 h-6" />,
    color: 'pink'
  },
  {
    title: 'Smart Risk - الدورة الكاملة',
    instructor: 'خبراء التداول',
    platform: 'يوتيوب',
    url: 'https://youtube.com/@smart_risk?si=8VLFIUyBN-9rm7L6',
    icon: <Play className="w-6 h-6" />,
    color: 'red'
  }
];

export default function Education() {
  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">القسم التعليمي</h2>
        <p className="text-gray-600">أفضل الكورسات والمصادر التعليمية لتعلم التداول</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {courses.map((course, index) => (
          <div key={index} className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow p-6">
            <div className="flex items-start space-x-4 space-x-reverse">
              <div className={`
                p-3 rounded-lg
                ${course.color === 'red' ? 'bg-red-100 text-red-600' : ''}
                ${course.color === 'pink' ? 'bg-pink-100 text-pink-600' : ''}
              `}>
                {course.icon}
              </div>
              
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{course.title}</h3>
                
                <div className="flex items-center space-x-2 space-x-reverse mb-2">
                  <User className="w-4 h-4 text-gray-500" />
                  <span className="text-sm text-gray-600">{course.instructor}</span>
                </div>
                
                <div className="mb-4">
                  <span className="inline-block bg-gray-100 text-gray-700 px-2 py-1 rounded-full text-xs">
                    {course.platform}
                  </span>
                </div>
                
                <a
                  href={course.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center space-x-2 space-x-reverse bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>مشاهدة الكورس</span>
                </a>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-12 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-8">
        <h3 className="text-xl font-bold text-gray-900 mb-4">نصائح للتعلم الفعال</h3>
        <div className="grid gap-4 md:grid-cols-2">
          <div className="flex items-start space-x-3 space-x-reverse">
            <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
            <p className="text-gray-700">ابدأ بالأساسيات قبل الانتقال للمفاهيم المتقدمة</p>
          </div>
          <div className="flex items-start space-x-3 space-x-reverse">
            <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
            <p className="text-gray-700">مارس التداول الوهمي قبل استخدام أموال حقيقية</p>
          </div>
          <div className="flex items-start space-x-3 space-x-reverse">
            <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
            <p className="text-gray-700">تابع أكثر من مصدر تعليمي لتنويع المعرفة</p>
          </div>
          <div className="flex items-start space-x-3 space-x-reverse">
            <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
            <p className="text-gray-700">اهتم بإدارة المخاطر والنفسية في التداول</p>
          </div>
        </div>
      </div>
    </div>
  );
}