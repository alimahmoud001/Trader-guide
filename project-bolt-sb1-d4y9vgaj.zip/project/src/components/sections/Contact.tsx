import React from 'react';
import { Phone, Mail, MessageCircle, MapPin, Clock } from 'lucide-react';

export default function Contact() {
  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">التواصل معنا</h2>
        <p className="text-gray-600">نحن هنا لمساعدتك في رحلتك في عالم التداول</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Contact Information */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">معلومات التواصل</h3>
          
          <div className="space-y-4">
            <div className="flex items-center space-x-3 space-x-reverse">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Phone className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="font-medium text-gray-900">الهاتف</p>
                <p className="text-gray-600">0934598967</p>
              </div>
            </div>

            <div className="flex items-center space-x-3 space-x-reverse">
              <div className="p-2 bg-green-100 rounded-lg">
                <Mail className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="font-medium text-gray-900">البريد الإلكتروني</p>
                <p className="text-gray-600">alimahmoud001a@gmail.com</p>
              </div>
            </div>

            <div className="flex items-center space-x-3 space-x-reverse">
              <div className="p-2 bg-purple-100 rounded-lg">
                <MessageCircle className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <p className="font-medium text-gray-900">تلجرام</p>
                <a 
                  href="https://t.me/tradewithali002" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-blue-600 hover:text-blue-800"
                >
                  @tradewithali002
                </a>
              </div>
            </div>

            <div className="flex items-center space-x-3 space-x-reverse">
              <div className="p-2 bg-red-100 rounded-lg">
                <MapPin className="w-5 h-5 text-red-600" />
              </div>
              <div>
                <p className="font-medium text-gray-900">الموقع</p>
                <p className="text-gray-600">اللاذقية، سورية</p>
              </div>
            </div>

            <div className="flex items-center space-x-3 space-x-reverse">
              <div className="p-2 bg-yellow-100 rounded-lg">
                <Clock className="w-5 h-5 text-yellow-600" />
              </div>
              <div>
                <p className="font-medium text-gray-900">ساعات العمل</p>
                <p className="text-gray-600">24/7 متاح دائماً</p>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Contact Form */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">رسالة سريعة</h3>
          
          <form className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                الاسم
              </label>
              <input
                type="text"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                البريد الإلكتروني
              </label>
              <input
                type="email"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                الموضوع
              </label>
              <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="">اختر الموضوع</option>
                <option value="trading">استفسار عن التداول</option>
                <option value="usdt">خدمة USDT</option>
                <option value="education">الدورات التعليمية</option>
                <option value="technical">مشكلة تقنية</option>
                <option value="other">أخرى</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                الرسالة
              </label>
              <textarea
                rows={4}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <button
              type="submit"
              className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors"
            >
              إرسال الرسالة
            </button>
          </form>
        </div>
      </div>

      {/* Additional Information */}
      <div className="mt-8 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">لماذا تختارنا؟</h3>
        <div className="grid gap-4 md:grid-cols-3">
          <div className="text-center">
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
              <Phone className="w-6 h-6 text-blue-600" />
            </div>
            <h4 className="font-medium text-gray-900 mb-1">دعم 24/7</h4>
            <p className="text-sm text-gray-600">متاحون دائماً لمساعدتك</p>
          </div>
          
          <div className="text-center">
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
              <MessageCircle className="w-6 h-6 text-green-600" />
            </div>
            <h4 className="font-medium text-gray-900 mb-1">استجابة سريعة</h4>
            <p className="text-sm text-gray-600">نرد على استفساراتك بسرعة</p>
          </div>
          
          <div className="text-center">
            <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-2">
              <Mail className="w-6 h-6 text-purple-600" />
            </div>
            <h4 className="font-medium text-gray-900 mb-1">خدمة احترافية</h4>
            <p className="text-sm text-gray-600">فريق خبراء في التداول</p>
          </div>
        </div>
      </div>
    </div>
  );
}