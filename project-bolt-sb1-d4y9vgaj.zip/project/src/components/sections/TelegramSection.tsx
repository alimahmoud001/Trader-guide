import React from 'react';
import { ExternalLink, Star, MessageCircle, DollarSign } from 'lucide-react';

const channels = [
  {
    name: 'قناتنا الرسمية',
    description: 'اشتراك شهري 30 دولار',
    url: 'https://t.me/tradewithali002',
    type: 'premium',
    isPremium: true
  },
  {
    name: 'FX_IRI',
    description: 'قناة إشارات ممتازة',
    url: 'https://t.me/FX_IRI',
    type: 'signals'
  },
  {
    name: 'Pro Signals FX',
    description: 'إشارات احترافية مجانية',
    url: 'https://t.me/prosignalsfxx',
    type: 'signals'
  },
  {
    name: 'Top Trading Signals',
    description: 'أفضل إشارات التداول',
    url: 'https://t.me/top_tradingsignals',
    type: 'signals'
  },
  {
    name: 'Signals FC',
    description: 'إشارات يومية مجانية',
    url: 'https://t.me/signalsfc',
    type: 'signals'
  },
  {
    name: 'Elite Trading Signals',
    description: 'إشارات نخبة المتداولين',
    url: 'https://t.me/elitetrading_signals',
    type: 'signals'
  },
  {
    name: 'Free Signals',
    description: 'إشارات مجانية يومية',
    url: 'https://t.me/free_signals',
    type: 'signals'
  },
  {
    name: 'Grey Suit Community',
    description: 'مجتمع المتداولين المحترفين',
    url: 'https://t.me/greysuitcommunity',
    type: 'community'
  }
];

export default function TelegramSection() {
  const premiumChannels = channels.filter(c => c.isPremium);
  const signalChannels = channels.filter(c => c.type === 'signals' && !c.isPremium);
  const communityChannels = channels.filter(c => c.type === 'community');

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">قنوات التلجرام</h2>
        <p className="text-gray-600">أفضل قنوات التلجرام للإشارات والتعليم</p>
      </div>

      {/* Premium Channels */}
      <div className="mb-8">
        <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center space-x-2 space-x-reverse">
          <DollarSign className="w-5 h-5 text-yellow-600" />
          <span>القنوات المدفوعة</span>
        </h3>
        <div className="grid gap-4">
          {premiumChannels.map((channel, index) => (
            <div key={index} className="bg-gradient-to-r from-yellow-50 to-orange-50 rounded-lg shadow-md p-6 border border-yellow-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3 space-x-reverse">
                  <div className="p-2 bg-yellow-100 rounded-lg">
                    <Star className="w-5 h-5 text-yellow-600" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-gray-900">{channel.name}</h4>
                    <p className="text-yellow-700 font-medium">{channel.description}</p>
                  </div>
                </div>
                <a
                  href={channel.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-yellow-600 text-white px-4 py-2 rounded-lg hover:bg-yellow-700 transition-colors flex items-center space-x-2 space-x-reverse"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>اشتراك</span>
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Signal Channels */}
      <div className="mb-8">
        <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center space-x-2 space-x-reverse">
          <MessageCircle className="w-5 h-5 text-green-600" />
          <span>قنوات الإشارات المجانية</span>
        </h3>
        <div className="grid gap-4 md:grid-cols-2">
          {signalChannels.map((channel, index) => (
            <div key={index} className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3 space-x-reverse">
                  <div className="p-2 bg-green-100 rounded-lg">
                    <MessageCircle className="w-5 h-5 text-green-600" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-gray-900">{channel.name}</h4>
                    <p className="text-gray-600 text-sm">{channel.description}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-1 space-x-reverse">
                  <span className="text-green-600">💯</span>
                </div>
              </div>
              <a
                href={channel.url}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center justify-center space-x-2 space-x-reverse"
              >
                <ExternalLink className="w-4 h-4" />
                <span>انضم للقناة</span>
              </a>
            </div>
          ))}
        </div>
      </div>

      {/* Community Channels */}
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center space-x-2 space-x-reverse">
          <MessageCircle className="w-5 h-5 text-blue-600" />
          <span>مجتمعات المتداولين</span>
        </h3>
        <div className="grid gap-4">
          {communityChannels.map((channel, index) => (
            <div key={index} className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3 space-x-reverse">
                  <div className="p-2 bg-blue-100 rounded-lg">
                    <MessageCircle className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-gray-900">{channel.name}</h4>
                    <p className="text-gray-600 text-sm">{channel.description}</p>
                  </div>
                </div>
                <a
                  href={channel.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2 space-x-reverse"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>انضم</span>
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}