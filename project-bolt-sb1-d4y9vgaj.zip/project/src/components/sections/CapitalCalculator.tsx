import React, { useState, useEffect } from 'react';
import { Calculator, TrendingUp, BarChart3 } from 'lucide-react';

interface CalculationResult {
  averageReturn: number;
  requiredTrades: number;
  totalGrowthRate: number;
  updates: Array<{ trade: number; capital: number; profit: number; loss: number }>;
}

export default function CapitalCalculator() {
  const [initialCapital, setInitialCapital] = useState<number>(1000);
  const [winRate, setWinRate] = useState<number>(60);
  const [profitRate, setProfitRate] = useState<number>(2);
  const [lossRate, setLossRate] = useState<number>(1);
  const [tradesPerUpdate, setTradesPerUpdate] = useState<number>(10);
  const [targetCapital, setTargetCapital] = useState<number>(10000);
  const [result, setResult] = useState<CalculationResult | null>(null);

  useEffect(() => {
    calculateGrowth();
  }, [initialCapital, winRate, profitRate, lossRate, tradesPerUpdate, targetCapital]);

  const calculateGrowth = () => {
    const winRateDecimal = winRate / 100;
    const lossRateDecimal = (100 - winRate) / 100;
    const profitRateDecimal = profitRate / 100;
    const lossRateDecimal_amount = lossRate / 100;

    // Calculate average return per trade
    const averageReturn = (winRateDecimal * profitRateDecimal) - (lossRateDecimal * lossRateDecimal_amount);
    
    // Calculate required trades to reach target
    const growthFactor = targetCapital / initialCapital;
    const requiredTrades = Math.log(growthFactor) / Math.log(1 + averageReturn);
    
    // Calculate total growth rate
    const totalGrowthRate = ((targetCapital - initialCapital) / initialCapital) * 100;

    // Generate updates table
    const updates = [];
    let currentCapital = initialCapital;
    let tradeCount = 0;

    while (currentCapital < targetCapital && tradeCount < requiredTrades) {
      const profitAmount = currentCapital * profitRateDecimal;
      const lossAmount = currentCapital * lossRateDecimal_amount;
      
      // Simulate trades based on win rate
      for (let i = 0; i < tradesPerUpdate; i++) {
        if (Math.random() < winRateDecimal) {
          currentCapital += profitAmount;
        } else {
          currentCapital -= lossAmount;
        }
        tradeCount++;
      }

      updates.push({
        trade: tradeCount,
        capital: Math.round(currentCapital),
        profit: Math.round(profitAmount),
        loss: Math.round(lossAmount)
      });

      if (updates.length >= 20) break; // Limit updates for display
    }

    setResult({
      averageReturn: averageReturn * 100,
      requiredTrades: Math.ceil(requiredTrades),
      totalGrowthRate,
      updates
    });
  };

  return (
    <div className="max-w-6xl mx-auto">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">حاسبة تطور رأس المال</h2>
        <p className="text-gray-600">احسب معدل نمو رأس المال بناءً على نسبة الربح والخسارة</p>
      </div>

      <div className="grid gap-8 lg:grid-cols-2">
        {/* Input Form */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center space-x-2 space-x-reverse">
            <Calculator className="w-5 h-5 text-blue-600" />
            <span>إدخال البيانات</span>
          </h3>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                رأس المال الأولي ($)
              </label>
              <input
                type="number"
                value={initialCapital}
                onChange={(e) => setInitialCapital(Number(e.target.value))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                نسبة الصفقات الرابحة (%)
              </label>
              <input
                type="number"
                value={winRate}
                onChange={(e) => setWinRate(Number(e.target.value))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                min="0"
                max="100"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                معدل الربح لكل صفقة (%)
              </label>
              <input
                type="number"
                value={profitRate}
                onChange={(e) => setProfitRate(Number(e.target.value))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                step="0.1"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                معدل الخسارة لكل صفقة (%)
              </label>
              <input
                type="number"
                value={lossRate}
                onChange={(e) => setLossRate(Number(e.target.value))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                step="0.1"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                عدد الصفقات في كل تحديث
              </label>
              <input
                type="number"
                value={tradesPerUpdate}
                onChange={(e) => setTradesPerUpdate(Number(e.target.value))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                الهدف النهائي ($)
              </label>
              <input
                type="number"
                value={targetCapital}
                onChange={(e) => setTargetCapital(Number(e.target.value))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
        </div>

        {/* Results */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center space-x-2 space-x-reverse">
            <TrendingUp className="w-5 h-5 text-green-600" />
            <span>النتائج</span>
          </h3>

          {result && (
            <div className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <div className="text-sm text-gray-600">متوسط العائد لكل صفقة</div>
                  <div className="text-xl font-bold text-blue-600">{result.averageReturn.toFixed(2)}%</div>
                </div>
                
                <div className="bg-green-50 p-4 rounded-lg">
                  <div className="text-sm text-gray-600">عدد الصفقات المطلوبة</div>
                  <div className="text-xl font-bold text-green-600">{result.requiredTrades}</div>
                </div>
                
                <div className="bg-purple-50 p-4 rounded-lg md:col-span-2">
                  <div className="text-sm text-gray-600">معدل النمو الإجمالي</div>
                  <div className="text-xl font-bold text-purple-600">{result.totalGrowthRate.toFixed(2)}%</div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Progress Table */}
      {result && result.updates.length > 0 && (
        <div className="mt-8 bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center space-x-2 space-x-reverse">
            <BarChart3 className="w-5 h-5 text-blue-600" />
            <span>جدول تطور رأس المال</span>
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full table-auto">
              <thead>
                <tr className="bg-gray-50">
                  <th className="px-4 py-2 text-right text-sm font-medium text-gray-700">عدد الصفقات</th>
                  <th className="px-4 py-2 text-right text-sm font-medium text-gray-700">رأس المال ($)</th>
                  <th className="px-4 py-2 text-right text-sm font-medium text-gray-700">الربح المتوقع ($)</th>
                  <th className="px-4 py-2 text-right text-sm font-medium text-gray-700">الخسارة المحتملة ($)</th>
                </tr>
              </thead>
              <tbody>
                {result.updates.map((update, index) => (
                  <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                    <td className="px-4 py-2 text-sm text-gray-900">{update.trade}</td>
                    <td className="px-4 py-2 text-sm font-medium text-gray-900">{update.capital.toLocaleString()}</td>
                    <td className="px-4 py-2 text-sm text-green-600">{update.profit.toLocaleString()}</td>
                    <td className="px-4 py-2 text-sm text-red-600">{update.loss.toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}