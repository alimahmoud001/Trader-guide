import React from 'react';
import { ExternalLink, Shield, Smartphone, TrendingUp } from 'lucide-react';

const apps = [
  {
    name: 'منصة ميتا تريدر 5',
    description: 'المنصة الموثوقة الأفضل في مجال التداول في جميع الأسواق',
    url: 'https://play.google.com/store/apps/details?id=net.metaquotes.metatrader5',
    icon: <TrendingUp className="w-6 h-6" />,
    color: 'blue'
  },
  {
    name: 'المحفظة الالكترونية - بايننس',
    description: 'منصة تداول العملات الرقمية الأكثر شهرة',
    url: 'https://www.binance.com/activity/referral-entry/CPA?ref=CPA_004C6HBMJS',
    icon: <Smartphone className="w-6 h-6" />,
    color: 'yellow'
  },
  {
    name: 'تطبيق المصادقة الثنائية',
    description: 'Google Authenticator لحماية إضافية للحسابات',
    url: 'https://play.google.com/store/apps/details?id=com.google.android.apps.authenticator2',
    icon: <Shield className="w-6 h-6" />,
    color: 'green'
  },
  {
    name: 'تطبيق التحليل - Trading View',
    description: 'أفضل منصة لتحليل الأسواق والرسوم البيانية',
    url: 'https://play.google.com/store/apps/details?id=com.tradingview.tradingviewapp',
    icon: <TrendingUp className="w-6 h-6" />,
    color: 'purple'
  }
];

export default function TradingApps() {
  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">تطبيقات يجب تحميلها للبدء بالتداول</h2>
        <p className="text-gray-600">مجموعة من التطبيقات الأساسية التي يحتاجها كل متداول</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {apps.map((app, index) => (
          <div key={index} className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow p-6">
            <div className="flex items-start space-x-4 space-x-reverse">
              <div className={`
                p-3 rounded-lg
                ${app.color === 'blue' ? 'bg-blue-100 text-blue-600' : ''}
                ${app.color === 'yellow' ? 'bg-yellow-100 text-yellow-600' : ''}
                ${app.color === 'green' ? 'bg-green-100 text-green-600' : ''}
                ${app.color === 'purple' ? 'bg-purple-100 text-purple-600' : ''}
              `}>
                {app.icon}
              </div>
              
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{app.name}</h3>
                <p className="text-gray-600 text-sm mb-4 leading-relaxed">{app.description}</p>
                
                <a
                  href={app.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center space-x-2 space-x-reverse bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>تحميل التطبيق</span>
                </a>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}