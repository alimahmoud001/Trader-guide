import React, { useState } from 'react';
import { DollarSign, Copy, CheckCircle, Send, AlertCircle } from 'lucide-react';

interface FormData {
  fullName: string;
  phone: string;
  city: string;
  transactionType: 'buy' | 'sell' | '';
  amount: string;
  network: string;
  walletAddress: string;
  paymentMethod: string;
  accountDetails: string;
  notes: string;
}

const EXCHANGE_RATE = 10000; // 1 USD = 10,000 SYP
const COMMISSION_FIXED = 1; // $1 fixed commission
const COMMISSION_PERCENTAGE = 0.5; // 0.5% commission
const NETWORK_FEE = 2; // $2 network fee for TRC20

export default function USDTService() {
  const [formData, setFormData] = useState<FormData>({
    fullName: '',
    phone: '',
    city: '',
    transactionType: '',
    amount: '',
    network: '',
    walletAddress: '',
    paymentMethod: '',
    accountDetails: '',
    notes: ''
  });

  const [copiedAddress, setCopiedAddress] = useState<string>('');
  const [showOrderSummary, setShowOrderSummary] = useState(false);

  const cryptoAddresses = {
    bep20: '0x21802218d8d661d66F2C7959347a6382E1cc614F',
    trc20: 'TD2LoErPRkVPBxDk72ZErtiyi6agirZQjX',
    erc20: '0x21802218d8d661d66F2C7959347a6382E1cc614F',
    binancepay: '969755964'
  };

  const paymentDetails = {
    shamcash: {
      address: 'be456e0ea9392db4d68a7093ee317bc8',
      account: '5991161126028260'
    },
    syriatelcash: {
      address: '0934598967'
    },
    alahram: {
      name: 'علي ابراهيم محمود',
      phone: '0934598967',
      city: 'اللاذقية'
    },
    bemo: {
      name: 'علي ابراهيم محمود',
      account: '060104947910013000000'
    }
  };

  const copyToClipboard = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    setCopiedAddress(type);
    setTimeout(() => setCopiedAddress(''), 2000);
  };

  const calculateCommission = () => {
    const amount = parseFloat(formData.amount) || 0;
    const fixedCommission = COMMISSION_FIXED;
    const percentageCommission = amount * (COMMISSION_PERCENTAGE / 100);
    const networkFee = formData.network === 'trc20' ? NETWORK_FEE : 0;
    
    return {
      fixed: fixedCommission,
      percentage: percentageCommission,
      network: networkFee,
      total: fixedCommission + percentageCommission + networkFee
    };
  };

  const calculateTotal = () => {
    const amount = parseFloat(formData.amount) || 0;
    const commission = calculateCommission();
    
    if (formData.transactionType === 'buy') {
      return (amount + commission.total) * EXCHANGE_RATE;
    } else {
      return (amount - commission.total) * EXCHANGE_RATE;
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowOrderSummary(true);
  };

  const sendOrder = () => {
    const commission = calculateCommission();
    const total = calculateTotal();
    
    const emailBody = `
طلب ${formData.transactionType === 'buy' ? 'شراء' : 'بيع'} USDT

بيانات المستخدم:
- الاسم الثلاثي: ${formData.fullName}
- رقم الهاتف: ${formData.phone}
- المدينة: ${formData.city}

تفاصيل الطلب:
- نوع العملية: ${formData.transactionType === 'buy' ? 'شراء' : 'بيع'}
- الكمية: ${formData.amount} USDT
- الشبكة: ${formData.network}
- عنوان المحفظة: ${formData.walletAddress}
- طريقة الدفع: ${formData.paymentMethod}
- تفاصيل الحساب: ${formData.accountDetails}
- ملاحظات: ${formData.notes}

تفاصيل العمولة:
- عمولة ثابتة: $${commission.fixed}
- عمولة نسبية: $${commission.percentage.toFixed(2)}
- رسوم الشبكة: $${commission.network}
- إجمالي العمولة: $${commission.total.toFixed(2)}

المبلغ الإجمالي: ${total.toLocaleString()} ل.س
    `;

    const mailtoLink = `mailto:alimahmoud001a@gmail.com?subject=طلب ${formData.transactionType === 'buy' ? 'شراء' : 'بيع'} USDT&body=${encodeURIComponent(emailBody)}`;
    window.open(mailtoLink);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">خدمة شراء وبيع USDT</h2>
        <p className="text-gray-600">تحويل USDT بوسائل الدفع المتاحة في سورية</p>
      </div>

      {!showOrderSummary ? (
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Personal Information */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">البيانات الشخصية</h3>
            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  الاسم الثلاثي
                </label>
                <input
                  type="text"
                  value={formData.fullName}
                  onChange={(e) => setFormData({...formData, fullName: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  رقم الهاتف
                </label>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({...formData, phone: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  المدينة
                </label>
                <input
                  type="text"
                  value={formData.city}
                  onChange={(e) => setFormData({...formData, city: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
            </div>
          </div>

          {/* Transaction Type */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">نوع العملية</h3>
            <div className="grid gap-4 md:grid-cols-2">
              <button
                type="button"
                onClick={() => setFormData({...formData, transactionType: 'buy'})}
                className={`p-4 rounded-lg border-2 transition-colors ${
                  formData.transactionType === 'buy' 
                    ? 'border-green-500 bg-green-50 text-green-700' 
                    : 'border-gray-300 hover:border-gray-400'
                }`}
              >
                <DollarSign className="w-6 h-6 mx-auto mb-2" />
                <span className="font-medium">شراء USDT</span>
              </button>
              <button
                type="button"
                onClick={() => setFormData({...formData, transactionType: 'sell'})}
                className={`p-4 rounded-lg border-2 transition-colors ${
                  formData.transactionType === 'sell' 
                    ? 'border-red-500 bg-red-50 text-red-700' 
                    : 'border-gray-300 hover:border-gray-400'
                }`}
              >
                <DollarSign className="w-6 h-6 mx-auto mb-2" />
                <span className="font-medium">بيع USDT</span>
              </button>
            </div>
          </div>

          {/* Transaction Details */}
          {formData.transactionType && (
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">تفاصيل العملية</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    الكمية (USDT)
                  </label>
                  <input
                    type="number"
                    value={formData.amount}
                    onChange={(e) => setFormData({...formData, amount: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    step="0.01"
                    min="0"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    الشبكة
                  </label>
                  <select
                    value={formData.network}
                    onChange={(e) => setFormData({...formData, network: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  >
                    <option value="">اختر الشبكة</option>
                    <option value="bep20">BEP20</option>
                    <option value="trc20">TRC20</option>
                    <option value="erc20">ERC20</option>
                    <option value="binancepay">Binance Pay</option>
                  </select>
                </div>

                {formData.transactionType === 'buy' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      عنوان المحفظة
                    </label>
                    <input
                      type="text"
                      value={formData.walletAddress}
                      onChange={(e) => setFormData({...formData, walletAddress: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    />
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    ملاحظات (اختياري)
                  </label>
                  <textarea
                    value={formData.notes}
                    onChange={(e) => setFormData({...formData, notes: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    rows={3}
                  />
                </div>
              </div>
            </div>
          )}

          {/* Payment Method */}
          {formData.transactionType && (
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                {formData.transactionType === 'buy' ? 'طريقة الدفع' : 'طريقة الاستلام'}
              </h3>
              <div>
                <select
                  value={formData.paymentMethod}
                  onChange={(e) => setFormData({...formData, paymentMethod: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                >
                  <option value="">اختر طريقة {formData.transactionType === 'buy' ? 'الدفع' : 'الاستلام'}</option>
                  <option value="shamcash">شام كاش</option>
                  <option value="syriatelcash">سيريتل كاش</option>
                  <option value="alahram">حوالة الهرم</option>
                  <option value="bemo">بنك بيمو</option>
                </select>
              </div>

              {formData.transactionType === 'sell' && formData.paymentMethod && (
                <div className="mt-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    تفاصيل الحساب
                  </label>
                  <input
                    type="text"
                    value={formData.accountDetails}
                    onChange={(e) => setFormData({...formData, accountDetails: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder={
                      formData.paymentMethod === 'bemo' ? 'رقم الحساب البنكي' :
                      formData.paymentMethod === 'shamcash' ? 'رقم الحساب أو عنوان الحساب' :
                      'تفاصيل الحساب'
                    }
                    required
                  />
                </div>
              )}
            </div>
          )}

          {/* Payment Details for Buy Orders */}
          {formData.transactionType === 'buy' && formData.paymentMethod && (
            <div className="bg-blue-50 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-blue-900 mb-4">تفاصيل الدفع</h3>
              
              {formData.paymentMethod === 'shamcash' && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span>العنوان:</span>
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <span className="font-mono text-sm">{paymentDetails.shamcash.address}</span>
                      <button
                        type="button"
                        onClick={() => copyToClipboard(paymentDetails.shamcash.address, 'shamcash-address')}
                        className="p-1 hover:bg-blue-200 rounded"
                      >
                        {copiedAddress === 'shamcash-address' ? 
                          <CheckCircle className="w-4 h-4 text-green-600" /> : 
                          <Copy className="w-4 h-4 text-blue-600" />
                        }
                      </button>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>رقم الحساب:</span>
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <span className="font-mono text-sm">{paymentDetails.shamcash.account}</span>
                      <button
                        type="button"
                        onClick={() => copyToClipboard(paymentDetails.shamcash.account, 'shamcash-account')}
                        className="p-1 hover:bg-blue-200 rounded"
                      >
                        {copiedAddress === 'shamcash-account' ? 
                          <CheckCircle className="w-4 h-4 text-green-600" /> : 
                          <Copy className="w-4 h-4 text-blue-600" />
                        }
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {formData.paymentMethod === 'syriatelcash' && (
                <div className="flex items-center justify-between">
                  <span>العنوان:</span>
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <span className="font-mono text-sm">{paymentDetails.syriatelcash.address}</span>
                    <button
                      type="button"
                      onClick={() => copyToClipboard(paymentDetails.syriatelcash.address, 'syriatel')}
                      className="p-1 hover:bg-blue-200 rounded"
                    >
                      {copiedAddress === 'syriatel' ? 
                        <CheckCircle className="w-4 h-4 text-green-600" /> : 
                        <Copy className="w-4 h-4 text-blue-600" />
                      }
                    </button>
                  </div>
                </div>
              )}

              {formData.paymentMethod === 'alahram' && (
                <div className="space-y-2">
                  <div><span className="font-medium">الاسم:</span> {paymentDetails.alahram.name}</div>
                  <div><span className="font-medium">الهاتف:</span> {paymentDetails.alahram.phone}</div>
                  <div><span className="font-medium">المدينة:</span> {paymentDetails.alahram.city}</div>
                </div>
              )}

              {formData.paymentMethod === 'bemo' && (
                <div className="space-y-2">
                  <div><span className="font-medium">الاسم:</span> {paymentDetails.bemo.name}</div>
                  <div className="flex items-center justify-between">
                    <span className="font-medium">رقم الحساب:</span>
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <span className="font-mono text-sm">{paymentDetails.bemo.account}</span>
                      <button
                        type="button"
                        onClick={() => copyToClipboard(paymentDetails.bemo.account, 'bemo')}
                        className="p-1 hover:bg-blue-200 rounded"
                      >
                        {copiedAddress === 'bemo' ? 
                          <CheckCircle className="w-4 h-4 text-green-600" /> : 
                          <Copy className="w-4 h-4 text-blue-600" />
                        }
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Crypto Addresses for Sell Orders */}
          {formData.transactionType === 'sell' && formData.network && (
            <div className="bg-green-50 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-green-900 mb-4">عنوان الإرسال</h3>
              <div className="flex items-center justify-between">
                <span className="font-medium">{formData.network.toUpperCase()}:</span>
                <div className="flex items-center space-x-2 space-x-reverse">
                  <span className="font-mono text-sm break-all">{cryptoAddresses[formData.network as keyof typeof cryptoAddresses]}</span>
                  <button
                    type="button"
                    onClick={() => copyToClipboard(cryptoAddresses[formData.network as keyof typeof cryptoAddresses], formData.network)}
                    className="p-1 hover:bg-green-200 rounded"
                  >
                    {copiedAddress === formData.network ? 
                      <CheckCircle className="w-4 h-4 text-green-600" /> : 
                      <Copy className="w-4 h-4 text-green-600" />
                    }
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Commission Info */}
          {formData.amount && (
            <div className="bg-yellow-50 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-yellow-900 mb-4">تفاصيل العمولة</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>عمولة ثابتة:</span>
                  <span>${calculateCommission().fixed}</span>
                </div>
                <div className="flex justify-between">
                  <span>عمولة نسبية (0.5%):</span>
                  <span>${calculateCommission().percentage.toFixed(2)}</span>
                </div>
                {formData.network === 'trc20' && (
                  <div className="flex justify-between">
                    <span>رسوم الشبكة:</span>
                    <span>${calculateCommission().network}</span>
                  </div>
                )}
                <div className="flex justify-between font-medium border-t pt-2">
                  <span>إجمالي العمولة:</span>
                  <span>${calculateCommission().total.toFixed(2)}</span>
                </div>
                <div className="flex justify-between font-bold text-lg border-t pt-2">
                  <span>المبلغ الإجمالي:</span>
                  <span>{calculateTotal().toLocaleString()} ل.س</span>
                </div>
              </div>
            </div>
          )}

          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2 space-x-reverse"
          >
            <Send className="w-5 h-5" />
            <span>إرسال الطلب</span>
          </button>
        </form>
      ) : (
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="text-center mb-6">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">تم إرسال الطلب بنجاح!</h3>
            <p className="text-gray-600">سيتم معالجة طلبك في أقرب وقت ممكن</p>
          </div>

          <div className="bg-gray-50 rounded-lg p-4 mb-6">
            <h4 className="font-semibold text-gray-900 mb-2">ملخص الطلب:</h4>
            <div className="space-y-1 text-sm">
              <div className="flex justify-between">
                <span>نوع العملية:</span>
                <span>{formData.transactionType === 'buy' ? 'شراء' : 'بيع'}</span>
              </div>
              <div className="flex justify-between">
                <span>الكمية:</span>
                <span>{formData.amount} USDT</span>
              </div>
              <div className="flex justify-between">
                <span>الشبكة:</span>
                <span>{formData.network}</span>
              </div>
              <div className="flex justify-between">
                <span>طريقة {formData.transactionType === 'buy' ? 'الدفع' : 'الاستلام'}:</span>
                <span>{formData.paymentMethod}</span>
              </div>
              <div className="flex justify-between font-bold">
                <span>المبلغ الإجمالي:</span>
                <span>{calculateTotal().toLocaleString()} ل.س</span>
              </div>
            </div>
          </div>

          <div className="bg-blue-50 rounded-lg p-4 mb-6">
            <div className="flex items-start space-x-3 space-x-reverse">
              <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
              <div>
                <p className="text-sm text-blue-800">
                  <strong>ملاحظة مهمة:</strong> عمولة التسديد على طرق التحويل المختلفة بالليرة السورية تقع على المستخدم كما تحددها هذه الجهات.
                </p>
              </div>
            </div>
          </div>

          <div className="flex space-x-4 space-x-reverse">
            <button
              onClick={sendOrder}
              className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors"
            >
              إرسال تفاصيل الطلب بالبريد الإلكتروني
            </button>
            <button
              onClick={() => setShowOrderSummary(false)}
              className="flex-1 bg-gray-600 text-white py-2 px-4 rounded-lg hover:bg-gray-700 transition-colors"
            >
              تعديل الطلب
            </button>
          </div>
        </div>
      )}
    </div>
  );
}