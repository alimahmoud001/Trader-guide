import React, { useState } from 'react';
import { Menu, X, Calculator, DollarSign, BookOpen, MessageCircle, Smartphone, Phone } from 'lucide-react';
import Sidebar from './Sidebar';
import TradingApps from './sections/TradingApps';
import TelegramSection from './sections/TelegramSection';
import Education from './sections/Education';
import CapitalCalculator from './sections/CapitalCalculator';
import USDTService from './sections/USDTService';
import Contact from './sections/Contact';

export interface Section {
  id: string;
  title: string;
  icon: React.ReactNode;
  component: React.ComponentType;
}

const sections: Section[] = [
  {
    id: 'apps',
    title: 'تطبيقات التداول',
    icon: <Smartphone className="w-5 h-5" />,
    component: TradingApps
  },
  {
    id: 'telegram',
    title: 'قنوات التلجرام',
    icon: <MessageCircle className="w-5 h-5" />,
    component: TelegramSection
  },
  {
    id: 'education',
    title: 'القسم التعليمي',
    icon: <BookOpen className="w-5 h-5" />,
    component: Education
  },
  {
    id: 'calculator',
    title: 'حاسبة تطور رأس المال',
    icon: <Calculator className="w-5 h-5" />,
    component: CapitalCalculator
  },
  {
    id: 'usdt',
    title: 'خدمة شراء وبيع USDT',
    icon: <DollarSign className="w-5 h-5" />,
    component: USDTService
  },
  {
    id: 'contact',
    title: 'التواصل معنا',
    icon: <Phone className="w-5 h-5" />,
    component: Contact
  }
];

export default function Layout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('apps');

  const ActiveComponent = sections.find(s => s.id === activeSection)?.component || TradingApps;

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-40">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center space-x-4 space-x-reverse">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
            >
              {sidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
            <h1 className="text-xl font-bold text-gray-900">دليل المتداول</h1>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <Sidebar
          isOpen={sidebarOpen}
          sections={sections}
          activeSection={activeSection}
          onSectionChange={setActiveSection}
          onClose={() => setSidebarOpen(false)}
        />

        {/* Main Content */}
        <main className="flex-1 transition-all duration-300">
          <div className="p-6">
            <ActiveComponent />
          </div>
        </main>
      </div>
    </div>
  );
}