import React from 'react';
import { Section } from './Layout';

interface SidebarProps {
  isOpen: boolean;
  sections: Section[];
  activeSection: string;
  onSectionChange: (sectionId: string) => void;
  onClose: () => void;
}

export default function Sidebar({ isOpen, sections, activeSection, onSectionChange, onClose }: SidebarProps) {
  return (
    <>
      {/* Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <div className={`
        fixed lg:static inset-y-0 right-0 z-50 w-64 bg-white shadow-xl transform transition-transform duration-300 ease-in-out
        ${isOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'}
      `}>
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">الأقسام</h2>
        </div>
        
        <nav className="mt-6">
          {sections.map((section) => (
            <button
              key={section.id}
              onClick={() => {
                onSectionChange(section.id);
                onClose();
              }}
              className={`
                w-full flex items-center space-x-3 space-x-reverse px-6 py-3 text-right hover:bg-gray-50 transition-colors
                ${activeSection === section.id ? 'bg-blue-50 text-blue-700 border-l-4 border-blue-700' : 'text-gray-700'}
              `}
            >
              {section.icon}
              <span className="font-medium">{section.title}</span>
            </button>
          ))}
        </nav>
      </div>
    </>
  );
}